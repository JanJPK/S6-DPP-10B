def add_two(x, y):
    return x + y

def increase(x):
    return x * 5